# Fundamentals of Web Development, 2nd Edition
### Chapter 8 [JavaScript 1: Language Foundations], Lab

What You Will Learn
* Linking JavaScript into your HTML files
* The basics of JavaScript syntax
* Working with functions and events